

public class Main {

    public static void main(String[] args) {
        GumballMachine gumballMachine = new GumballMachine(5);

        System.out.println(gumballMachine);

        gumballMachine.insertQuarter(25, 10, 10, 989);
        gumballMachine.turnCrank();
        
        gumballMachine.turnCrank();
        System.out.println(gumballMachine);
    }
}
