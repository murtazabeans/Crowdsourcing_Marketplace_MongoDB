

public interface State {
 
	public void insertQuarter(int...coins);
	public void ejectQuarter();
	public void turnCrank();
	public void dispense();
}
