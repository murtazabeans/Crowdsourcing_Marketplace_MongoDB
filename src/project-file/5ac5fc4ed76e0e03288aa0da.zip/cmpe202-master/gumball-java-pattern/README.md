# Assignment-2

UML Diagrams in Astah and Implementation of Machines
 **Gumball Machines** .

