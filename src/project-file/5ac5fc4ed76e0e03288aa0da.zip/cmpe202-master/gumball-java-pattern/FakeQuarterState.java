
/**
 * Write a description of class FakeQuarterState here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FakeQuarterState implements State
{
    // instance variables - replace the example below with your own
    GumballMachine gumballMachine;
    public FakeQuarterState(GumballMachine gumballMachine) {
        this.gumballMachine = gumballMachine;
    }
    
    public void insertQuarter(int...coins) {
        System.out.println("You inserted a fake quarter");
        gumballMachine.setState(gumballMachine.getFakeQuarterState());
    }
    
    public void ejectQuarter() {
        System.out.println("You haven't inserted a quarter");
    }
    
    public void turnCrank() {
        System.out.println("You turned, but there is a fake quarter");
     }
    
    public void dispense() {
        System.out.println("You need to put real quarter first");
    } 
    
    public String toString() {
        return "waiting for quarter";
    }
}
