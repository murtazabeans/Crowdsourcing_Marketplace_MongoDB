
/**
 * Write a description of class GumballMachineImplementation here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GumballMachineImplementation
{
    // instance variables - replace the example below with your own
    GumballMachine gumballMachine;
    public int sum = 0;
    /**
     * Constructor for objects of class GumballMachineImplementation
     */
    
    
    public boolean isFakeCurrency(int...coins){
        for(int i = 0; i < coins.length; i++){
            if(coins[i] != 5 && coins[i] != 10 && coins[i] != 25){
                return true;
            }
        }
        return false;
    }
    
    public String getGumballMachine(int...coins){
        int total_coins = coins.length;
        if(total_coins == 1 && coins[0] == 25){
            return "Quarter";
        }
        else if(total_coins == 2 && coins[0] == 25 && coins[1] == 25){
            return "DoubleQuarter";
        }
        else if(total_coins > 2){
            return "MultipleCoins";
        }
        
        else{
            return "NoQuarter";
        }
    }
}
