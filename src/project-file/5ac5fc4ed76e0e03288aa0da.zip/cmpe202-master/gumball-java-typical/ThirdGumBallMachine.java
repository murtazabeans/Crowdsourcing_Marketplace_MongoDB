
/**
 * Write a description of class ThirdGumBallMachine here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ThirdGumBallMachine extends GumballMachine
{
    // instance variables - replace the example below with your own
    private int num_gumballs;
    private boolean has_quarter;
    private int number_of_gumballs_to_be_ejected = 0;
    
    public ThirdGumBallMachine( int size )
    {
        // initialise instance variables
        this.num_gumballs = size;
        this.has_quarter = false;
    }
    
    public void insertQuater(int...coins)
    {   
        int sum = 0;
        for(int i = 0; i < coins.length ; i++){
            if(coins[i] == 5 || coins[i] == 10 || coins[i] == 25){
                sum += coins[i];
            }
            System.out.println(sum);
        }
        number_of_gumballs_to_be_ejected = sum / 50;
        
        this.has_quarter = false ;
        if(sum >=50){
            this.has_quarter = true ;
        }
        else{
            this.has_quarter = false ;
        }
    }
    
     public void turnCrank()
    {
        System.out.println( "Gumball Machine 3 initialised" );
        if ( this.has_quarter )
        {
            if ( this.num_gumballs > this.number_of_gumballs_to_be_ejected )
            {
                this.num_gumballs-- ;
                this.has_quarter = false ;
                System.out.println( "Thanks for your quarter.  Gumball Ejected!" ) ;
            }
            else
            {
                System.out.println( "Insufficient Gumballs!  Sorry, can't return your quarter." ) ;
            }
        }
        else 
        {
            System.out.println( "Sum of coins should be 50 or more" ) ;
        }        
    } 
}
