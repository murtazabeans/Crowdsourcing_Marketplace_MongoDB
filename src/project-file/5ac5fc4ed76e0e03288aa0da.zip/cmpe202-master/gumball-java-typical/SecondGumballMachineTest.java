

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class SecondGumballMachineTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SecondGumballMachineTest
{
    private SecondGumballMachine secondGu1;

    /**
     * Default constructor for test class SecondGumballMachineTest
     */
    public SecondGumballMachineTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
        secondGu1 = new SecondGumballMachine(5);
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }

    @Test
    public void testExample()
    {
        secondGu1.insertQuater(25, 25);
        secondGu1.turnCrank();
        assertEquals(true, secondGu1.hasGumball());
    }
}

