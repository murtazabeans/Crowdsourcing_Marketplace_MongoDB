
/**
 * Write a description of class SecondGumballMachine here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class SecondGumballMachine extends GumballMachine
{
    // instance variables - replace the example below with your own
    private int num_gumballs;
    private boolean has_quarter;
    private boolean gumball_in_slot;
    
    public SecondGumballMachine( int size )
    {
        // initialise instance variables
        this.num_gumballs = size;
        this.has_quarter = false;
        this.gumball_in_slot = false;
    }
    
    public boolean hasGumball(){
        return gumball_in_slot;
    }
    
    public void insertQuater(int coin1, int coin2)
    {
        if ( coin1 == 25 && coin2 == 25)
            this.has_quarter = true ;
        else 
            this.has_quarter = false ;
    }
    
     public void turnCrank()
    {
        System.out.println( "Gumball Machine 2 initialised" );
   	if ( this.has_quarter )
    	{
    		if ( this.num_gumballs > 0 )
    		{
    			this.num_gumballs-- ;
    			this.has_quarter = false ;
    			this.gumball_in_slot = true;
    			System.out.println( "Thanks for your quarter.  Gumball Ejected!" ) ;
    		}
    		else
    		{
    			System.out.println( "No More Gumballs!  Sorry, can't return your quarter." ) ;
    		}
    	}
    	else 
    	{
    		System.out.println( "Please insert a quarter" ) ;
    	}        
    } 
    
}

