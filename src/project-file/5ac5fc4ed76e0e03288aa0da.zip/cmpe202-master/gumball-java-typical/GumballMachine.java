
public abstract class GumballMachine
{
    public void insertQuater(int coin){};
    public void turnCrank(){};
}

