

public class Main {

    public static void main(String[] args) {
        //GumballMachine gumballMachine = new GumballMachine(5);
        GumballMachine fgm = new FirstGumBallMachine(3);
        SecondGumballMachine sgm = new SecondGumballMachine(5);
        ThirdGumBallMachine tgm = new ThirdGumBallMachine(6);
        
        fgm.insertQuater(25);
        fgm.turnCrank();
        
        sgm.insertQuater(25, 25);
        sgm.turnCrank();
        
        tgm.insertQuater(5, 10, 10, 25);
        tgm.turnCrank();
        
        //System.out.println(gumballMachine);

        //gumballMachine.insertQuarter( 25 );
        //gumballMachine.turnCrank();

        //System.out.println(gumballMachine);

        //gumballMachine.insertQuarter( 25 );
        //gumballMachine.turnCrank();
        //gumballMachine.insertQuarter( 25 );
        //gumballMachine.turnCrank();

        //System.out.println(gumballMachine);
    }
}
