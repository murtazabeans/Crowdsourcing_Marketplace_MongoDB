var express = require('express');
var bodyParser = require('body-parser');
//and create our instances
var app = express();
var router = express.Router();
var mysql = require('mysql');

