import React, { Component } from 'react';
import {connect} from 'react-redux';  
import {bindActionCreators} from 'redux';
import axios from 'axios';

class Home extends Component {
  constructor(props){
    super(props);
    this.state = {name: '', email: ''}

    this.handleSignOut = this.handleSignOut.bind(this);
  }

  componentWillMount(){
    var self = this;
    axios.get('http://localhost:3001/check_session', { withCredentials: true })
    .then((response) => {
      debugger
      if(response.data.session.email !=  undefined){
        self.setState({name: response.data.session.name, email: response.data.session.email});
      }
      else{
        window.location.href = "http://localhost:3000/signin";
      }
    })
  }

  handleSignOut(e){

    var self = this;
    axios.get('http://localhost:3001/destroy_session', { withCredentials: true })
    .then((response) => {
      self.props.history.push("/signin")
      self.setState({})
    })
  }

  render(props) {

    return (
    <div id = "detail">
      <h2>Welcome {this.state.name}</h2>
      <br/>
      <br/>

      <h6> You have successfully logged in! Your email id is {this.state.email}</h6>

      <a className="link-style nav-link btn-info home-page-link" onClick = {this.handleSignOut} href="#">Sign Out</a>
    </div>
    )
  }
}

function mapStateToProps(state){
  return{
    user: state.userLoggedIn
  }
}

export default connect(mapStateToProps)(Home);